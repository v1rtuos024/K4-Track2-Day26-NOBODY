# Đội NOBODY

| Họ tên đầy đủ | MSSV |
|---|---|
| Nguyễn Thành Vinh | 2a202602889 |
